 rm *.aux *.acn *.toc *.acr *.alg *.ist *.lof *.nlo *.nls *.gls *.bbl *.glo *.glg *.glsdefs *.ilg *.log *.blg *.lot *.out

